import pymysql
# import mimetypes
# mimetypes.add_type("css", ".css", True)
# mimetypes.add_type("javascript", ".js", True)
pymysql.install_as_MySQLdb()