from django.db import models

class DataModel(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255)
    instruct = models.CharField(max_length=3000)
    data_version = models.CharField(max_length=100)
    class Meta:
        db_table = 'chatgpt_instruct'