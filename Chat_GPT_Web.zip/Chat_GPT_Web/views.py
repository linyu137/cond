from datetime import datetime
from  django.db  import  connections
from django.http import HttpResponse
from django.shortcuts import render, redirect
from .models import DataModel


def data_input(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        instruct = request.POST.get('instruct')
        if name == "" or instruct == "" or name == None or instruct == None:
            return render(request, 'data_input.html', {'result': "你怕是在瞎搞啊,啥都不写就想提交"})
        # 存储数据到数据库
        now_time = str(datetime.now())
        try:
            spider_time = now_time.split(".")[0]
            data_version = spider_time.split(" ")[0]
            data = DataModel(name=str(name), instruct=str(instruct), data_version=str(data_version))
            data.save()
            return render(request, 'data_input.html', {'result': "恭喜恭喜指令入库成功"})
        except:
            return render(request, 'data_input.html', {'result': "指令入库失败了啊"})
    elif request.method == "GET":
        start_time = request.GET.get('start_time')
        delete_name = request.GET.get('delete_name')
        print("delete_name=====", delete_name)
        if start_time:
            try:
                #  查询数据库
                cursor = connections['default'].cursor()
                sql ="SELECT  id,name  FROM  chatgpt_instruct  WHERE  data_version  =  %s  "
                sqlres = cursor.execute(sql, [start_time])
                results = cursor.fetchall()
                if sqlres == 0:
                    return render(request, 'data_input.html',
                                  {'result': "查询" + str(start_time) + "失败"})
                else:
                    return render(request, 'data_input.html', {'results': results})
            except Exception as e:
                print("e",e)
                return render(request, 'data_input.html', {'result': "查询错误"})

        elif delete_name:
            try:
                cursor = connections['default'].cursor()
                sql = "DELETE FROM chatgpt_instruct WHERE name = %s"
                sqlres = cursor.execute(sql, [delete_name])
                # 提交事务
                connections['default'].commit()
                if sqlres == 0:
                    return render(request, 'data_input.html',
                                  {'result': "删除" + str(delete_name) + "失败"})
                else:
                    return render(request, 'data_input.html', {'result': "删除了" + str(delete_name)+"请重新查询列表查看"})
            except Exception as e:
                print("e", e)
                return render(request, 'data_input.html', {'result': "删除错误"})
        else:
            return render(request, 'data_input.html', {'result': "要删除还是查询,随便写点啥的啊"})




    return render(request, 'data_input.html')


def page_not_found(request, exception):
    return render(request, '404.html', status=404)